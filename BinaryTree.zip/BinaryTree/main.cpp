#include <iostream>
#include <string>

/*

Reference used for the Project is the inclass Binary Tree Example
Provided by Eric Darsow of Technology Rediscovery

*/

using namespace std;

struct BowlingNode
{
    BowlingNode(BowlingNode* bowl, int score, string name)
    :bowlParent{bowl}, payload{score}, searchVar{name}
    {
        //Setting the Left and Right Child Pointers to null
        leftChild = nullptr;
        rightChild = nullptr;
    }

    //Search Value
    BowlingNode * bowlParent;
    string searchVar;
    int payload;

    BowlingNode* leftChild;
    BowlingNode* rightChild;
};

//LeaderBoard Root
BowlingNode* leaderBoard;

//Create New Node

/*
struct BowlingNode* newBowlingScore(int score, string name)
{
    struct BowlingNode* temp = new BowlingNode;
    temp->score = score;
    temp->left  = temp->right = NULL;
    return temp;
}
*/

//InOrder Traversal Function
void inOrder(BowlingNode* bowlRoot)
{
    if(bowlRoot != nullptr)
    {
        //Call the Root's Left Child
        inOrder(bowlRoot->leftChild);
        cout << bowlRoot->payload;
        //Call the Root's Right Child
        cout << " " << bowlRoot->searchVar << endl;
        inOrder(bowlRoot->rightChild);
    }
}


int main()
{
    //Calling BowlingNode Root Class
    BowlingNode* bowlNode = new BowlingNode(leaderBoard, 150, "Sean");

    //Create First Node of Tree
    leaderBoard = bowlNode;

    //Holds a reference to the temparent
    BowlingNode* tempParent = leaderBoard;


    bowlNode = new BowlingNode(leaderBoard, 134, "Jimmy");

    //Assign to Left Node
    tempParent->leftChild = bowlNode;

    bowlNode = new BowlingNode(leaderBoard, 161, "Phil");

    //Assign to Right Node
    tempParent->rightChild = bowlNode;

    tempParent = bowlNode;
    bowlNode = new BowlingNode(leaderBoard, 230, "Toby");

    //Assign to Right Node
    tempParent->rightChild = bowlNode;


    //Call InOrder Function
    inOrder(leaderBoard);

    return 0;
}
